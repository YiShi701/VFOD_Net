import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"

import torch
import torch.nn as nn
from loss.iouloss import IOU_loss
from loss.msssimLoss import MSSSIM
from loss.focalloss import BinaryFocalLoss

bce_loss = nn.BCELoss(size_average=True)
# loss_base = IOU_loss(pred,label)
loss_base2 = MSSSIM()
loss_focal = BinaryFocalLoss()


input = torch.rand(25,25)
label = torch.zeros(25,25)
# print('---0011---')
# print(type(input))
# input = torch.arange(1, 65, dtype=torch.LongTensor).view(4, 1, 4, 4)
# label = torch.arange(11, 75, dtype=torch.LongTensor).view(4, 1, 4, 4)

# input = torch.LongTensor(input).cuda()
# label = torch.LongTensor(label).cuda()
input = input.cuda()
label = label.cuda()
print(type(input))
# input = torch.sigmoid(input)
loss = loss_focal(input,label)
print(loss)
loss.backward()

# loss2 = bce_loss(input,label)
# print(loss2)
#
# loss3 = loss_base2(input,label)
# print(loss3)
