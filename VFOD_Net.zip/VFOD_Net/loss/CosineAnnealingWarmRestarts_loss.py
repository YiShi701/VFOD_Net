##余弦退火学习率(Cosine Annealing LR)
## 余弦退火学习率中LR的变化是周期性的，T_max是周期的1/2；
# eta_min(float)表示学习率的最小值，默认为0；
# torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max,eta_min=0,last_epoch=-1)

import torch
from torchvision.models import AlexNet
from torch.optim.lr_scheduler import CosineAnnealingLR, CosineAnnealingWarmRestarts
import matplotlib.pyplot as plt

model = AlexNet(num_classes=2)
optimizer = torch.optim.Adam(model.parameters(),lr=0.1)
# scheduler = CosineAnnealingLR(optimizer,T_max=10)
scheduler = CosineAnnealingLR(optimizer,T_max=10,eta_min=0.004)
scheduler = CosineAnnealingWarmRestarts(optimizer,T_max=10,eta_min=0.004)

plt.figure()
x = list(range(100))
y = []
for epoch in range(1,101):
    optimizer.zero_grad()
    optimizer.step()
    print("第%d个epoch的学习率：%f" % (epoch,optimizer.param_groups[0]['lr']))
    scheduler.step()
    y.append(scheduler.get_lr()[0])

# 画出lr的变化
plt.plot(x, y)
plt.xlabel("epoch")
plt.ylabel("lr")
plt.title("learning rate's curve changes as epoch goes on!")
plt.show()