
import torch
import torch.nn as nn
import logging
from utils.autoanchor import check_anchor_order
from model_doubone.common import *
from utils.torch_utils import *

logger = logging.getLogger(__name__)

class Conv(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=0, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups=1
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, p, groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

    def forward(self, x):
        x1 = self.conv(x)
        x2 = self.bn(x1)
        return self.act(x2)

    def fuseforward(self, x):
        return self.act(self.conv(x))

class Focus(nn.Module):
    # Focus wh information into c-space
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super(Focus, self).__init__()
        self.conv = Conv(c1 * 4, c2, k, s, p, g, act)

    def forward(self, x):  # x(b,c,w,h) -> y(b,4c,w/2,h/2)
        return self.conv(torch.cat([x[..., ::2, ::2], x[..., 1::2, ::2], x[..., ::2, 1::2], x[..., 1::2, 1::2]], 1))


class Bottleneck(nn.Module):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super(Bottleneck, self).__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c2, 3, 1, 1, g=g)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        return x + self.cv2(self.cv1(x)) if self.add else self.cv2(self.cv1(x))

class BottleneckCSP(nn.Module):
    def __init__(self, c1, c2, e=1, shortcut=True, num=3):
        super().__init__()
        # c1 = int(c1*e)
        self.cv1 = Conv(c1, c2, k=1, s=1, p=0, act=True)
        self.cv2 = nn.Conv2d(c1, c2, 1, 1, bias=False)
        self.cv3 = nn.Conv2d(c2, c2, 1, 1, bias=False)
        if e == 1:
            self.cv4 = Conv(c1, c1, k=1, s=1, p=0)
            self.bn = nn.BatchNorm2d(c1)
        else:
            self.cv4 = Conv(int(c1 * 0.5), int(c1 * 0.5), k=1, s=1, p=0)
            self.bn = nn.BatchNorm2d(int(c1 * 0.5))

        self.act = nn.LeakyReLU(0.1, inplace=True)
        self.m = nn.Sequential(*[Bottleneck(c2, c2, shortcut, g=1, e=1.0) for _ in range(num)])

    def forward(self, x):
        x1 = self.cv1(x)
        m1 = self.m(x1)
        x2 = self.cv3(m1)
        x3 = self.cv2(x)
        cat1 = torch.cat((x2, x3), dim=1)
        bn1 = self.bn(cat1)
        act1 = self.act(bn1)
        return self.cv4(act1)


class C3(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, e=1, shortcut=True, num=3):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        # c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c2, 1, 1)
        self.cv2 = Conv(c1, c2, 1, 1)
        if e == 1:
            self.cv3 = Conv(c1, c1, 1)
        else:
            self.cv3 = Conv(int(c1 * 0.5), int(c1 * 0.5), 1)

        # self.cv3 = Conv(2 * c_, c2, 1)  # act=FReLU(c2)
        self.m = nn.Sequential(*[Bottleneck(c2, c2, shortcut, g=1, e=1.0) for _ in range(num)])
        # self.m = nn.Sequential(*[CrossConv(c_, c_, 3, 1, g, 1.0, shortcut) for _ in range(n)])

    def forward(self, x):
        # return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))
        m1 = self.m(self.cv1(x))
        x2 = self.cv2(x)
        cat1 = torch.cat((m1, x2), dim=1)
        return self.cv3(cat1)

class C3_FPN(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, e=1, shortcut=True, num=3):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        # c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c2, 1, 1)
        self.cv2 = Conv(c1, c2, 1, 1)
        if e == 1:
            self.cv3 = Conv(c1, c1, 1)
        else:
            self.cv3 = Conv(int(c2 * 2), int(c2 * 2), 1)
        self.m = nn.Sequential(*[Bottleneck(c2, c2, shortcut, g=1, e=1.0) for _ in range(num)])

    def forward(self, x):
        # return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))
        m1 = self.m(self.cv1(x))
        x2 = self.cv2(x)
        cat1 = torch.cat((m1, x2), dim=1)
        return self.cv3(cat1)

class C32(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, e=1, shortcut=True, num=3):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        # c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c2, 1, 1)
        self.cv2 = Conv(c1, c2, 1, 1)
        if e == 1:
            self.cv3 = Conv(c1, c2, 1)
        else:
            self.cv3 = Conv(int(c1 * 0.5), int(c1 * 0.5), 1)

        # self.cv3 = Conv(2 * c_, c2, 1)  # act=FReLU(c2)
        self.m = nn.Sequential(*[Bottleneck(c2, c2, shortcut, g=1, e=1.0) for _ in range(num)])
        # self.m = nn.Sequential(*[CrossConv(c_, c_, 3, 1, g, 1.0, shortcut) for _ in range(n)])

    def forward(self, x):
        # return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))
        m1 = self.m(self.cv1(x))
        x2 = self.cv2(x)
        cat1 = torch.cat((m1, x2), dim=1)
        return self.cv3(cat1)


#### neck
class SPP(nn.Module):
    # Spatial pyramid pooling layer used in YOLOv3-SPP
    def __init__(self, c1, c2, k=(5, 9, 13)):
        super().__init__()
        self.cv1 = Conv(c1, c2, 1, 1)
        self.cv2 = Conv(c2 * (len(k) + 1), c1, 1, 1)
        # self.maxpool1 = nn.MaxPool2d(kernel_size=5, stride=1, padding=5 // 2)
        # self.maxpool2 = nn.MaxPool2d(kernel_size=9, stride=1, padding=9 // 2)
        # self.maxpool3 = nn.MaxPool2d(kernel_size=13, stride=1, padding=13 // 2)
        self.m = nn.ModuleList([nn.MaxPool2d(kernel_size=x, stride=1, padding=x // 2) for x in k])

    def forward(self, x):
        x1 = self.cv1(x)
        x2 = torch.cat([x1] + [m(x1) for m in self.m], 1)
        return self.cv2(x2)

class SPPF(nn.Module):
    # Spatial Pyramid Pooling - Fast (SPPF) layer for YOLOv5 by Glenn Jocher
    def __init__(self, c1, c2, k=5):  # equivalent to SPP(k=(5, 9, 13))
        super().__init__()
        c_ = c1 // 2  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * 4, c2, 1, 1)
        self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)

    def forward(self, x):
        x = self.cv1(x)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')  # suppress torch 1.9.0 max_pool2d() warning
            y1 = self.m(x)
            y2 = self.m(y1)
            return self.cv2(torch.cat([x, y1, y2, self.m(y2)], 1))



class Concat(nn.Module):
    def __init__(self, dimension=1):
        super().__init__()
        self.d = dimension

    def forward(self, x1, x2):
        return torch.cat((x1, x2), dim=1)

class Concat3(nn.Module):
    def __init__(self, dimension=1):
        super().__init__()
        self.d = dimension

    def forward(self, x1, x2, x3):
        return torch.cat((x1, x2, x3), dim=1)


class NMS(nn.Module):
    # Non-Maximum Suppression (NMS) module
    conf = 0.25  # confidence threshold
    iou = 0.45  # IoU threshold
    classes = None  # (optional list) filter by class

    def __init__(self):
        super(NMS, self).__init__()

    def forward(self, x):
        return non_max_suppression(x[0], conf_thres=self.conf, iou_thres=self.iou, classes=self.classes)

# ---------------------------------------------------- #

class channel_attention(nn.Module):
    def __init__(self, in_channel, ratio=4):
        super(channel_attention, self).__init__()
        self.max_pool = nn.AdaptiveMaxPool2d(output_size=1)
        self.avg_pool = nn.AdaptiveAvgPool2d(output_size=1)

        self.fc1 = nn.Linear(in_features=in_channel, out_features=in_channel // ratio, bias=False)
        self.fc2 = nn.Linear(in_features=in_channel // ratio, out_features=in_channel, bias=False)
        self.relu = nn.ReLU()
        self.sigmoid = nn.Sigmoid()

    def forward(self, inputs):
        b, c, h, w = inputs.shape
        max_pool = self.max_pool(inputs)
        avg_pool = self.avg_pool(inputs)
        max_pool = max_pool.view([b, c])
        avg_pool = avg_pool.view([b, c])
        x_maxpool = self.fc1(max_pool)
        x_avgpool = self.fc1(avg_pool)
        x_maxpool = self.relu(x_maxpool)
        x_avgpool = self.relu(x_avgpool)
        x_maxpool = self.fc2(x_maxpool)
        x_avgpool = self.fc2(x_avgpool)
        x = x_maxpool + x_avgpool
        x = self.sigmoid(x)
        x = x.view([b, c, 1, 1])
        outputs = inputs * x
        return outputs

# ---------------------------------------------------- #
class spatial_attention(nn.Module):
    def __init__(self, kernel_size=7):
        super(spatial_attention, self).__init__()
        padding = kernel_size // 2
        self.conv = nn.Conv2d(in_channels=2, out_channels=1, kernel_size=kernel_size,
                              padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, inputs):
        x_maxpool, _ = torch.max(inputs, dim=1, keepdim=True)
        x_avgpool = torch.mean(inputs, dim=1, keepdim=True)
        x = torch.cat([x_maxpool, x_avgpool], dim=1)
        x = self.conv(x)
        x = self.sigmoid(x)
        outputs = inputs * x
        return outputs

# ---------------------------------------------------- #
class cbam(nn.Module):
    def __init__(self, in_channel, ratio=4, kernel_size=7):
        super(cbam, self).__init__()
        self.channel_attention = channel_attention(in_channel=in_channel, ratio=ratio)
        self.spatial_attention = spatial_attention(kernel_size=kernel_size)

    def forward(self, inputs):
        x = self.channel_attention(inputs)
        x = self.spatial_attention(x)
        return x

class CrossAttention03(nn.Module):
    def __init__(self, input_dim, head_dim, num_heads):
        super(CrossAttention03, self).__init__()
        self.head_dim = head_dim
        self.num_heads = num_heads
        self.query_linear = nn.Linear(input_dim, head_dim * num_heads, bias=False)
        self.key_linear = nn.Linear(input_dim, head_dim * num_heads, bias=False)
        self.value_linear = nn.Linear(input_dim, head_dim * num_heads, bias=False)
        self.out_linear = nn.Linear(head_dim * num_heads, input_dim, bias=False)

    def forward(self, x1, x2):
        query = self.query_linear(x1)
        key = self.key_linear(x2)
        value = self.value_linear(x2) #torch.Size([ba, 836, 480])
        query = query.view(x1.size(0), -1, self.num_heads, self.head_dim).transpose(1, 2)
        key = key.view(x2.size(0), -1, self.num_heads, self.head_dim).transpose(1, 2)
        value1 = value.view(x2.size(0), -1, self.num_heads, self.head_dim).transpose(1, 2)
        attn_scores = torch.matmul(query, key.transpose(-2, -1)) / (self.head_dim ** 0.5)
        attn_scores = F.softmax(attn_scores, dim=-1)
        output = torch.matmul(attn_scores, value1)
        output = output.transpose(1, 2).contiguous().view(x1.size(0), -1, self.num_heads * self.head_dim)
        output = self.out_linear(output)
        out2 = output + value #
        return out2


class Detect(nn.Module):
    stride = None  # strides computed during build
    onnx_dynamic = False  # ONNX export parameter

    def __init__(self, inference=False, nc=5):  # detection layer
        super().__init__()
        self.inference = inference

        anchors = [[6, 6, 11, 13, 22, 20],
                   [23, 40, 40, 34, 62, 56],
                   [99, 82, 148, 130, 201, 185]]

        self.nc = nc  # number of classes
        self.no = nc + 5  # number of outputs per anchor
        self.nl = len(anchors)  # number of detection layers
        self.na = len(anchors[0]) // 2  # number of anchors
        self.grid = [torch.zeros(1)] * self.nl  # init grid
        self.anchor_grid = [torch.zeros(1)] * self.nl  # init anchor grid
        self.register_buffer('anchors', torch.tensor(anchors).float().view(self.nl, -1, 2))  # shape(nl,na,2)
        self.m = nn.ModuleList(nn.Conv2d(x, self.no * self.na, 1) for x in [120, 240, 480])  # output conv

    def forward(self, x):
        z = []  # inference output
        for i in range(self.nl):
            x[i] = self.m[i](x[i])  # conv
            bs, _, ny, nx = x[i].shape  # x(bs,255,20,20) to x(bs,3,20,20,85)
            x[i] = x[i].view(bs, self.na, self.no, ny, nx).permute(0, 1, 3, 4, 2).contiguous()

            # if not self.training:  # inference
            if self.inference:
                if self.onnx_dynamic or self.grid[i].shape[2:4] != x[i].shape[2:4]:
                    self.grid[i], self.anchor_grid[i] = self._make_grid(nx, ny, i)

                y = x[i].sigmoid()
                y[..., 0:2] = (y[..., 0:2] * 2 - 0.5 + self.grid[i]) * self.stride[i]  # xy
                y[..., 2:4] = (y[..., 2:4] * 2) ** 2 * self.anchor_grid[i]  # wh
                z.append(y.view(bs, -1, self.no))

        if self.inference:
            return torch.cat(z, 1), x

        else:
            return x

    def _make_grid(self, nx=20, ny=20, i=0):
        d = self.anchors[i].device
        if check_version(torch.__version__, '1.10.0'):  # torch>=1.10.0 meshgrid workaround for torch>=0.7 compatibility
            yv, xv = torch.meshgrid([torch.arange(ny, device=d), torch.arange(nx, device=d)], indexing='ij')
        else:
            yv, xv = torch.meshgrid([torch.arange(ny, device=d), torch.arange(nx, device=d)])
        grid = torch.stack((xv, yv), 2).expand((1, self.na, ny, nx, 2)).float()
        anchor_grid = (self.anchors[i].clone() * self.stride[i]) \
            .view((1, self.na, 1, 1, 2)).expand((1, self.na, ny, nx, 2)).float()
        return grid, anchor_grid

class VFOD_NET(nn.Module):
    def __init__(self, inference=False):  # model, input channels, number of classes
        super().__init__()
        self.inference = inference
        lay0 = Conv(3, 30, k=3, s=1, p=1)
        lay1 = Conv(30, 60, k=6, s=2, p=2)  # /2
        lay2 = Conv(60, 120, k=3, s=2, p=1)  # /4
        lay3 = C3(120, 60, num=2)
        lay4 = Conv(120, 240, k=3, s=2, p=1)  # /8
        lay5 = C3(240, 120, num=4)
        lay6 = Conv(240, 480, k=3, s=2, p=1)  # /16
        lay7 = C3(480, 240, num=6)
        lay8 = Conv(480, 960, k=3, s=2, p=1)  # /32
        lay9 = C3(960, 480, num=2)
        lay10 = SPPF(960, 960)  # lay8
        lay11 = Conv(960, 480, k=1, s=1, p=0)
        lay12 = nn.Upsample(scale_factor=2, mode='nearest') # /16
        lay13 = Concat()
        lay14 = C3(960, 240, e=0.5, shortcut=False, num=2)
        lay15 = Conv(480, 240, k=1, s=1, p=0)
        lay16 = nn.Upsample(scale_factor=2, mode='nearest') # /8
        lay17 = Concat() # lay14+lay4
        lay18 = C3(480, 120, e=0.5, shortcut=False, num=2)
        lay19 = Conv(240, 120, k=1, s=1, p=0)
        lay20 = nn.Upsample(scale_factor=2, mode='nearest') # /4
        lay21 = Concat()  # lay18+lay2
        lay22 = C3(240, 60, e=0.5, shortcut=False, num=2)
        lay23 = Conv(120, 60, k=1, s=1, p=0)
        lay24 = nn.Upsample(scale_factor=2, mode='nearest')  # /2
        lay25 = Concat()  # lay22+lay0
        lay26 = C3(120, 30, e=0.5, shortcut=False, num=2)
        lay27 = Conv(60, 30, k=1, s=1, p=0)
        lay28 = nn.Upsample(scale_factor=2, mode='nearest')  # /1
        lay29 = Concat()
        lay30 = Conv(60, 30, k=3, s=1, p=1)
        lay31 = nn.Conv2d(30, 1, kernel_size=3, padding=1)
        lay32 = nn.Conv2d(60, 1, kernel_size=3, padding=1)
        lay33 = Conv(3, 30, k=3, s=1, p=1)
        lay34 = Conv(30, 60, k=6, s=2, p=2)
        lay35 = Conv(60, 120, k=3, s=2, p=1)
        lay36 = C3(120, 60, num=2)
        lay37 = Conv(120, 240, k=3, s=2, p=1)
        lay38 = C3(240, 120, num=4)
        lay39 = Conv(240, 480, k=3, s=2, p=1)
        lay40 = C3(480, 240, num=6)
        lay41 = SPPF(480, 480)
        lay42 = Conv(480, 240, k=1, s=1, p=0)
        lay43 = nn.Upsample(scale_factor=2, mode='nearest')
        lay44 = Concat()
        lay45 = C3(480, 120, e=0.5, shortcut=False, num=2)
        lay46 = Conv(240, 120, k=1, s=1, p=0)
        lay47 = nn.Upsample(scale_factor=2, mode='nearest')
        lay48 = Concat()
        lay49 = C3(240, 60, e=0.5, shortcut=False, num=2)
        lay50 = Conv(120, 120, k=3, s=2, p=1)
        lay51 = Concat()
        lay52 = C3(240, 120, e=1, shortcut=False, num=2)
        lay53 = Conv(240, 240, k=3, s=2, p=1)
        lay54 = Concat()
        lay55 = C3(480, 240, shortcut=False, num=2)
        # detect head
        lay56 = Detect(inference)

        self.model = nn.Sequential(lay0, lay1, lay2, lay3, lay4, lay5, lay6, lay7, lay8, lay9, lay10, lay11, lay12,
                                   lay13, lay14, lay15, lay16, lay17, lay18, lay19, lay20, lay21, lay22, lay23, lay24,
                                   lay25, lay26, lay27, lay28, lay29, lay30, lay31, lay32, lay33, lay34, lay35, lay36,
                                   lay37, lay38, lay39, lay40, lay41, lay42, lay43, lay44, lay45, lay46, lay47, lay48,
                                   lay49, lay50, lay51, lay52, lay53, lay54, lay55, lay56)

        self.atten1 = cbam(in_channel=60)
        self.atten2 = cbam(in_channel=120)
        self.dow1 = Conv(90, 30, k=1, s=1, p=0)
        self.dow2 = Conv(180, 60, k=1, s=1, p=0)
        self.dow4 = Conv(360, 120, k=1, s=1, p=0)
        self.dow8 = Conv(720, 240, k=1, s=1, p=0)
        self.dow16 = Conv(1440, 480, k=1, s=1, p=0)
        self.dow32 = Conv(2880, 960, k=1, s=1, p=0)
        self.gamma1 = nn.Parameter(torch.ones(1))
        self.cat1 = Concat()
        self.cat2 = Concat()
        self.cat3 = Concat()
        self.cat1con1 = Conv(240, 120, k=1, s=1, p=0) # -
        self.cat2con2 = Conv(480, 240, k=1, s=1, p=0) #
        self.cat3con3 = Conv(960, 480, k=1, s=1, p=0)
        self.cros16 = CrossAttention03(input_dim=480, head_dim=80, num_heads=6)
        self.cros8 = CrossAttention03(input_dim=240, head_dim=60, num_heads=4)

        m = self.model[-1]  # Detect()
        if isinstance(m, Detect):
            m.stride = torch.tensor([4., 8., 16.])
            m.anchors /= m.stride.view(-1, 1, 1)
            check_anchor_order(m)
            self.stride = m.stride  # self.stride = <class 'torch.Tensor'>
            self._initialize_biases()  # only run once
        initialize_weights(self)

    def _initialize_biases(self, cf=None):  # initialize biases into Detect(), cf is class frequency
        # https://arxiv.org/abs/1708.02002 section 3.3
        # cf = torch.bincount(torch.tensor(np.concatenate(dataset.labels, 0)[:, 0]).long(), minlength=nc) + 1.
        m = self.model[-1]  # Detect() module
        for mi, s in zip(m.m, m.stride):  # from
            b = mi.bias.view(m.na, -1)  # conv.bias(255) to (3,85)
            b.data[:, 4] += math.log(8 / (608 / s) ** 2)  # obj (8 objects per 640 image)
            b.data[:, 5:] += math.log(0.6 / (m.nc - 0.99)) if cf is None else torch.log(cf / cf.sum())  # cls
            mi.bias = torch.nn.Parameter(b.view(-1), requires_grad=True)


    def fuse(self):  # fuse model Conv2d() + BatchNorm2d() layers
        print('Fusing layers... ')
        for m in self.model.modules():
            if type(m) is Conv and hasattr(m, 'bn'):
                m.conv = fuse_conv_and_bn(m.conv, m.bn)  # update conv
                delattr(m, 'bn')  # remove batchnorm
                m.forward = m.fuseforward  # update forward
        return self


    def nms(self, mode=True):  # add or remove NMS module
        present = type(self.model[-1]) is NMS  # last layer is NMS
        if mode and not present:
            print('Adding NMS... ')
            m = NMS()  # module
            m.f = -1  # from
            m.i = self.model[-1].i + 1  # index
            self.model.add_module(name='%s' % m.i, module=m)  # add
            self.eval()
        elif not mode and present:
            print('Removing NMS... ')
            self.model = self.model[:-1]  # remove
        return self

    def forward(self, input, input2):
        d0 = self.model[0](input)
        d1 = self.model[1](d0)
        da1 = self.atten1(d1)
        d2 = self.model[2](da1)
        da2 = self.atten2(d2)
        d3 = self.model[3](da2)
        d4 = self.model[4](d3)
        d5 = self.model[5](d4)
        d6 = self.model[6](d5)
        d7 = self.model[7](d6)
        d8 = self.model[8](d7)
        d9 = self.model[9](d8)
        original_size = torch.Size([input.size(0)//3, 3, d9.size(-3), d9.size(-2), d9.size(-1)])
        d90 = d9.view(original_size)
        d9 = torch.cat([d90[:,0,], d90[:,1,], d90[:,2,]], 1)
        d9 = self.dow32(d9)
        spp1 = self.model[10](d9)
        c11 = self.model[11](spp1)
        c12 = self.model[12](c11)
        original_size2 = torch.Size([input.size(0)//3, 3, d7.size(-3), d7.size(-2), d7.size(-1)])
        d70 = d7.view(original_size2)
        d7 = torch.cat([d70[:, 0, ], d70[:, 1, ], d70[:, 2, ]], 1)
        d7 = self.dow16(d7)
        c13 = self.model[13](c12,d7)
        c14 = self.model[14](c13)
        c15 = self.model[15](c14)
        c16 = self.model[16](c15)
        original_size3 = torch.Size([input.size(0)//3, 3, d5.size(-3), d5.size(-2), d5.size(-1)])
        d50 = d5.view(original_size3)
        d5 = torch.cat([d50[:, 0, ], d50[:, 1, ], d50[:, 2, ]], 1)
        d5 = self.dow8(d5)
        c17 = self.model[17](c16,d5)
        c18 = self.model[18](c17)
        c19 = self.model[19](c18)
        c20 = self.model[20](c19)
        original_size4 = torch.Size([input.size(0)//3, 3, d3.size(-3), d3.size(-2), d3.size(-1)])
        d30 = d3.view(original_size4)
        d3 = torch.cat([d30[:, 0, ], d30[:, 1, ], d30[:, 2, ]], 1)
        d3 = self.dow4(d3)
        c21 = self.model[21](c20,d3)
        c22 = self.model[22](c21)
        c23 = self.model[23](c22)
        c24 = self.model[24](c23)
        original_size5 = torch.Size([input.size(0)//3, 3, da1.size(-3), da1.size(-2), da1.size(-1)])
        da10 = da1.view(original_size5)
        da1 = torch.cat([da10[:, 0, ], da10[:, 1, ], da10[:, 2, ]], 1)
        da1 = self.dow2(da1)
        c25 = self.model[25](c24, da1)
        c26 = self.model[26](c25)
        c27 = self.model[27](c26)
        c28 = self.model[28](c27)
        original_size6 = torch.Size([input.size(0)//3, 3, d0.size(-3), d0.size(-2), d0.size(-1)])
        d00 = d0.view(original_size6)
        d0 = torch.cat([d00[:, 0, ], d00[:, 1, ], d00[:, 2, ]], 1)
        d0 = self.dow1(d0)
        c29 = self.model[29](c28, d0)
        c30 = self.model[30](c29)
        c31 = self.model[31](c30)
        c32 = self.model[32](c26)
        out1 = torch.sigmoid(c31)
        out2 = torch.sigmoid(c32)
        c33 = self.model[33](input2)
        f1 = self.gamma1 * out1 * c33
        fc33 = f1 + c33
        c34 = self.model[34](fc33)
        da21 = self.atten1(c34)
        f2 = self.gamma1 * out2 * da21
        fc34 = f2 + da21
        c35 = self.model[35](fc34)
        da22 = self.atten2(c35)
        cat1 = self.cat1(da22, c22)
        catcon1 = self.cat1con1(cat1)
        c36 = self.model[36](catcon1)
        c37 = self.model[37](c36)
        new_size = torch.Size([c37.size(0), c37.size(2) * c37.size(3), c37.size(1)])
        c372 = c37.permute(0, 2, 3, 1)
        c372 = c372.view(new_size)
        c182 = c18.permute(0, 2, 3, 1)
        c182 = c182.view(new_size)
        c372 = self.cros8(c182, c372)
        c372 = c372.view(c37.size(0), c37.size(2), c37.size(3), c37.size(1)).permute(0, 3, 1, 2)
        cat2 = self.cat2(c372, c18)
        catcon2 = self.cat2con2(cat2)
        c38 = self.model[38](catcon2)
        c39 = self.model[39](c38)
        new_size = torch.Size([c39.size(0), c39.size(2) * c39.size(3), c39.size(1)])
        c392 = c39.permute(0, 2, 3, 1)
        c392 = c392.view(new_size)
        c142 = c14.permute(0, 2, 3, 1)
        c142 = c142.view(new_size)
        c392 = self.cros16(c142, c392)
        c392 = c392.view(c39.size(0), c39.size(2), c39.size(3), c39.size(1)).permute(0, 3, 1, 2)
        cat3 = self.cat3(c392, c14)
        catcon3 = self.cat3con3(cat3)
        c40 = self.model[40](catcon3)
        spp2 = self.model[41](c40)
        c42 = self.model[42](spp2)
        c43 = self.model[43](c42)
        c44 = self.model[44](c43, c38)
        c45 = self.model[45](c44)
        c46 = self.model[46](c45)
        c47 = self.model[47](c46)
        c48 = self.model[48](c47, c36)
        c49 = self.model[49](c48)
        c50 = self.model[50](c49)
        c51 = self.model[51](c50, c46)
        c52 = self.model[52](c51)
        c53 = self.model[53](c52)
        c54 = self.model[54](c53, c42)
        c55 = self.model[55](c54)

        if self.inference:
            inf_out, train_out = self.model[56]([c49, c52, c55])
            return inf_out, train_out

        else:
            pred = self.model[56]([c49, c52, c55])
            return pred, out1, out2

